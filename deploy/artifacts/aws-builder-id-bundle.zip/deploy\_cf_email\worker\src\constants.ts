export const CONSTANTS = {
    VERSION: 'v' + '1.9.0',

    // DB Version
    DB_VERSION_KEY: 'db_version',
    DB_VERSION: "v0.0.7",

    // DB settings
    ADDRESS_BLOCK_LIST_KEY: 'address_block_list',
    SEND_BLOCK_LIST_KEY: 'send_block_list',
    AUTO_CLEANUP_KEY: 'auto_cleanup',
    USER_SETTINGS_KEY: 'user_settings',
    ADDRESS_CREATION_SETTINGS_KEY: 'address_creation_settings',
    OAUTH2_SETTINGS_KEY: 'oauth2_settings',
    VERIFIED_ADDRESS_LIST_KEY: 'verified_address_list',
    NO_LIMIT_SEND_ADDRESS_LIST_KEY: 'no_limit_send_address_list',
    EMAIL_RULE_SETTINGS_KEY: 'email_rule_settings',
    ROLE_ADDRESS_CONFIG_KEY: 'role_address_config',
    IP_BLACKLIST_SETTINGS_KEY: 'ip_blacklist_settings',
    AI_EXTRACT_SETTINGS_KEY: 'ai_extract_settings',

    // KV
    TG_KV_PREFIX: "temp-mail-telegram",
    TG_KV_SETTINGS_KEY: "temp-mail-telegram-settings",
    WEBHOOK_KV_SETTINGS_KEY: "temp-mail-webhook-settings",
    WEBHOOK_KV_USER_SETTINGS_KEY: "temp-mail-webhook-user-settings",
    EMAIL_KV_BLACK_LIST: "temp-mail-email-black-list",
    WEBHOOK_KV_ADMIN_MAIL_SETTINGS_KEY: "temp-mail-webhook-admin-mail-settings",
    SEND_MAIL_LIMIT_COUNT_KEY_PREFIX: "send_mail_limit_count:",
    SEND_MAIL_LIMIT_CONFIG_KEY: "send_mail_limit_config",
}
